

aplFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/AAPL.csv'
nasdaqFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/NASDAQ.csv'
xomFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/XOM.csv'

apl <- read.table(aplFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(apl)[2]<-"apl.price"
nasdaq <- read.table(nasdaqFile ,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(nasdaq)[2]<-"nasdaq.price"
xom <- read.table(xomFile ,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(xom)[2]<-"xom.price"

apl <- merge(apl, nasdaq, by = "Date")
apl <- merge(apl, xom, by = "Date")
apl[,c("Date")] <- as.Date(apl[,c("Date")],"%Y-%m-%d")
apl <- apl[order(apl$Date, decreasing = TRUE),]


apl[-nrow(apl),-1] <- apl[-nrow(apl),-1]/apl[-1,-1]-1
apl <- apl[-nrow(apl),]  
names(apl)[2:4] <- c("apl.returns","nasdaq.returns","xom.returns")
aplMultipleModel <- lm(apl$apl.returns ~ apl$nasdaq.returns + apl$xom.returns, na.action = na.omit)
summary(aplMultipleModel)


apl$Month = format(apl$Date,"%m")
aplMonthModel <- lm(apl$apl.returns~apl$nasdaq.returns+apl$Month+0)
summary(aplMonthModel)
