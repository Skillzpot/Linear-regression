

aplFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/AAPL.csv'
nasdaqFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/NASDAQ.csv'


apl <- read.table(aplFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(apl)[2]<-"apl.price"
nasdaq <- read.table(nasdaqFile ,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(nasdaq)[2]<-"nasdaq.price"

apl <- merge(apl, nasdaq, by = "Date")
apl[,c("Date")] <- as.Date(apl[,c("Date")],"%Y-%m-%d")
apl <- apl[order(apl$Date, decreasing = TRUE),]




apl[-nrow(apl),-1] <- apl[-nrow(apl),-1]/apl[-1,-1]-1
apl <- apl[-nrow(apl),]  
names(apl)[2:3] <- c("apl.returns","nasdaq.returns")

combined <- data.frame(apl[-nrow(apl),],apl[-1,-1])

names(combined)[4:5] <- c("apl.lagged_1","nasdaq.lagged_1")


combined$apl.UP = combined$apl.returns >= 0
fit <- glm(combined$apl.UP ~  combined$apl.lagged_1+combined$nasdaq.lagged_1,family=binomial())
summary(fit)
results <- data.frame(combined$apl.UP,fitted(fit) >= 0.5)
names(results) <- c("Actual","PredictedByLogistic")
results$CorrectForecast = results$Actual == results$PredictedByLogistic

length(results$CorrectForecast[results$CorrectForecast == TRUE]) / length(results$CorrectForecast)

