

aplFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/AAPL.csv'
nasdaqFile <- '/Users/swethakolalapudi/Desktop/Reg_Data/NASDAQ.csv'



apl <- read.table(aplFile,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(apl)[2]<-"apl.price"
nasdaq <- read.table(nasdaqFile ,header = TRUE, sep =",")[,c("Date","Adj.Close")]
names(nasdaq)[2]<-"nasdaq.price"

apl <- merge(apl, nasdaq, by = "Date")
apl[,c("Date")] <- as.Date(apl[,c("Date")],"%Y-%m-%d")
apl <- apl[order(apl$Date, decreasing = TRUE),]


plot(apl$nasdaq.price,apl$apl.price)

aplMisSpecified <- lm(apl$apl.price~apl$nasdaq.price)

plot(apl$nasdaq.price,aplMisSpecified$resid)
acf(aplMisSpecified$resid)
summary(aplMisSpecified)




apl[-nrow(apl),-1] <- apl[-nrow(apl),-1]/apl[-1,-1]-1
apl <- apl[-nrow(apl),]  
names(apl)[2:3] <- c("apl.returns","nasdaq.returns")

# Building a linear model
aplGoodModel <- lm(apl$apl.returns~apl$nasdaq.returns)
summary(aplGoodModel )


plot(apl$apl.returns,apl$nasdaq.returns)
plot(aplGoodModel$resid,apl$nasdaq.returns)
acf(aplGoodModel$resid)
summary(aplGoodModel)
plot(apl$nasdaq.returns,aplGoodModel$resid)
acf(aplGoodModel$resid)

length(apl$nasdaq.returns)



apl <- data.frame(nasdaq.returns = seq(-0.1,0.1,0.01))
length(apl$nasdaq.returns)
predict(aplGoodModel,apl)

